import { Job, Queue, QueueEvents, Worker } from "bullmq";
import { redis } from "~~/server/lib/redis";
import { queueNames, reconcileSchedulerQueue } from "~~/server/lib/bullmq";
import { processProviderCallback } from "~~/server/services/callbacks/processProviderCallback";
import { deliverWebhook } from "~~/server/services/webhooks/deliverWebhook";
import { reconcilePayment } from "~~/server/services/reconcile/reconcilePayment";
import { handleWebhookInboundJob } from "~~/server/services/webhooks/handleWebhookInboundJob";
import { logger } from "~~/server/lib/logger";
import { runWithRequestContext } from "~~/server/lib/request-context";
import { NonRetryableJobError } from "~~/server/tasks/job-errors";
import { enqueueReconcileCandidates } from "~~/server/services/reconcile/enqueueReconcileCandidates";

type QueuePolicy = {
  queueName: string;
  jobName: string;
  attempts: number;
  backoffDelayMs: number;
  concurrency: number;
};

const QUEUE_POLICIES = {
  providerCallback: {
    queueName: queueNames.callback,
    jobName: "provider.callback.process",
    attempts: 5,
    backoffDelayMs: 2000,
    concurrency: 20,
  },
  merchantWebhook: {
    queueName: queueNames.webhook,
    jobName: "merchant.webhook.deliver",
    attempts: 8,
    backoffDelayMs: 3000,
    concurrency: 50,
  },
  webhookInbound: {
    queueName: queueNames.webhookInbound,
    jobName: "provider.webhook.process",
    attempts: 5,
    backoffDelayMs: 2000,
    concurrency: 20,
  },
  reconcile: {
    queueName: queueNames.reconcile,
    jobName: "payment.reconcile.single",
    attempts: 3,
    backoffDelayMs: 5000,
    concurrency: 10,
  },
  reconcileScheduler: {
    queueName: queueNames.reconcileScheduler,
    jobName: "payment.reconcile.scan",
    attempts: 1,
    backoffDelayMs: 1000,
    concurrency: 1,
  },
} as const satisfies Record<string, QueuePolicy>;

type JobMeta = {
  requestId?: string;
  traceId?: string;
  provider?: string;
  tenantId?: string;
  apiKeyPrefix?: string;
  method?: string;
  path?: string;
  route?: string;
};

type JobDataWithMeta = {
  meta?: JobMeta;
  webhookEventId?: string;
  providerCallbackId?: string;
  paymentIntentId?: string;
  webhookDeliveryId?: string;
};

function getJobMeta(job: Job): JobMeta {
  const data = (job.data ?? {}) as JobDataWithMeta;
  return data.meta ?? {};
}

function getJobData(job: Job): JobDataWithMeta {
  return (job.data ?? {}) as JobDataWithMeta;
}

function serializeError(error: unknown) {
  if (error instanceof Error) {
    return {
      name: error.name,
      message: error.message,
      stack: error.stack,
      ...(error instanceof NonRetryableJobError && error.code
        ? { code: error.code }
        : {}),
    };
  }

  return {
    message: String(error),
  };
}

function logJobEvent(input: {
  level?: "info" | "warn" | "error";
  event: string;
  queue: string;
  job?: Job;
  data?: Record<string, unknown>;
  error?: unknown;
}) {
  const meta = input.job ? getJobMeta(input.job) : {};
  const jobData = input.job ? getJobData(input.job) : {};

  const payload = {
    event: input.event,
    queue: input.queue,
    jobId: input.job?.id,
    jobName: input.job?.name,
    attemptsMade: input.job?.attemptsMade,
    requestId: meta.requestId,
    traceId: meta.traceId,
    provider: meta.provider,
    tenantId: meta.tenantId,
    apiKeyPrefix: meta.apiKeyPrefix,
    method: meta.method,
    path: meta.path,
    route: meta.route,
    webhookEventId: jobData.webhookEventId,
    providerCallbackId: jobData.providerCallbackId,
    paymentIntentId: jobData.paymentIntentId,
    webhookDeliveryId: jobData.webhookDeliveryId,
    data: input.data,
    error: input.error ? serializeError(input.error) : undefined,
  };

  const level = input.level ?? "info";

  if (level === "error") {
    logger.error(payload, input.event);
    return;
  }

  if (level === "warn") {
    logger.warn(payload, input.event);
    return;
  }

  logger.info(payload, input.event);
}

const callbackDlq = new Queue(`${queueNames.callback}-dlq`, {
  connection: redis,
});

const webhookDlq = new Queue(`${queueNames.webhook}-dlq`, {
  connection: redis,
});

const webhookInboundDlq = new Queue(`${queueNames.webhookInbound}-dlq`, {
  connection: redis,
});

const reconcileDlq = new Queue(`${queueNames.reconcile}-dlq`, {
  connection: redis,
});

const reconcileSchedulerDlq = new Queue(
  `${queueNames.reconcileScheduler}-dlq`,
  {
    connection: redis,
  },
);

async function moveToDlq(params: {
  dlq: Queue;
  sourceQueue: string;
  job: Job;
  error: unknown;
}) {
  const { dlq, sourceQueue, job, error } = params;
  const data = getJobData(job);

  await dlq.add(
    `${job.name}.dlq`,
    {
      originalQueue: sourceQueue,
      originalJobId: job.id,
      originalJobName: job.name,
      failedAt: new Date().toISOString(),
      attemptsMade: job.attemptsMade + 1,
      payload: job.data,
      error: serializeError(error),
      meta: data.meta,
    },
    {
      jobId: `${sourceQueue}__dlq__${job.id}`,
      removeOnComplete: 1000,
      removeOnFail: 5000,
    },
  );

  logJobEvent({
    level: "warn",
    event: "job.moved_to_dlq",
    queue: sourceQueue,
    job,
    data: {
      dlqName: dlq.name,
      nonRetryable: error instanceof NonRetryableJobError,
    },
  });
}

function registerQueueEvents(queueName: string) {
  const events = new QueueEvents(queueName, { connection: redis });

  events.on("completed", ({ jobId }) => {
    logger.info(
      {
        event: "queue.completed_event",
        queue: queueName,
        jobId,
      },
      "queue.completed_event",
    );
  });

  events.on("failed", ({ jobId, failedReason }) => {
    logger.warn(
      {
        event: "queue.failed_event",
        queue: queueName,
        jobId,
        failedReason,
      },
      "queue.failed_event",
    );
  });

  return events;
}

function buildWorker(params: {
  queueName: string;
  jobName: string;
  concurrency: number;
  dlq: Queue;
  processor: (job: Job) => Promise<void>;
}) {
  const { queueName, jobName, concurrency, dlq, processor } = params;

  registerQueueEvents(queueName);

  const worker = new Worker(
    queueName,
    async (job) => {
      if (job.name !== jobName) {
        logJobEvent({
          level: "warn",
          event: "job.ignored_unexpected_name",
          queue: queueName,
          job,
          data: {
            expectedJobName: jobName,
          },
        });
        return;
      }

      logJobEvent({
        event: "job.started",
        queue: queueName,
        job,
        data: {
          webhookEventId: getJobData(job).webhookEventId,
          paymentIntentId: getJobData(job).paymentIntentId,
          traceId: getJobMeta(job).traceId,
          requestId: getJobMeta(job).requestId,
          provider: getJobMeta(job).provider,
          tenantId: getJobMeta(job).tenantId,
        },
      });

      try {
        const meta = getJobMeta(job);
        const data = getJobData(job);

        await runWithRequestContext(
          {
            ...(meta.requestId !== undefined && { requestId: meta.requestId }),
            ...(meta.traceId !== undefined && { traceId: meta.traceId }),
            ...(meta.provider !== undefined && { provider: meta.provider }),
            ...(meta.tenantId !== undefined && { tenantId: meta.tenantId }),
            ...(meta.apiKeyPrefix !== undefined && {
              apiKeyPrefix: meta.apiKeyPrefix,
            }),
            ...(meta.method !== undefined && { method: meta.method }),
            ...(meta.path !== undefined && { path: meta.path }),
            ...(meta.route !== undefined && { route: meta.route }),
            ...(data.webhookEventId !== undefined && {
              webhookEventId: data.webhookEventId,
            }),
            ...(data.paymentIntentId !== undefined && {
              paymentIntentId: data.paymentIntentId,
            }),
            queue: queueName,
            jobId: String(job.id),
            jobName: job.name,
          },
          async () => {
            await processor(job);
          },
        );

        logJobEvent({
          event: "job.completed",
          queue: queueName,
          job,
        });
      } catch (error) {
        logJobEvent({
          level: "error",
          event: "job.failed",
          queue: queueName,
          job,
          error,
        });

        const isNonRetryable = error instanceof NonRetryableJobError;

        if (isNonRetryable) {
          await moveToDlq({
            dlq,
            sourceQueue: queueName,
            job,
            error,
          });

          logJobEvent({
            level: "warn",
            event: "job.non_retryable",
            queue: queueName,
            job,
            error,
          });

          return;
        }

        const attemptsAllowed = job.opts.attempts ?? 1;
        const isFinalFailure = job.attemptsMade + 1 >= attemptsAllowed;

        if (isFinalFailure) {
          await moveToDlq({
            dlq,
            sourceQueue: queueName,
            job,
            error,
          });
        }

        throw error;
      }
    },
    { connection: redis, concurrency },
  );

  worker.on("error", (error) => {
    logger.error(
      {
        event: "worker.error",
        queue: queueName,
        error: serializeError(error),
      },
      "worker.error",
    );
  });

  return worker;
}

buildWorker({
  queueName: QUEUE_POLICIES.providerCallback.queueName,
  jobName: QUEUE_POLICIES.providerCallback.jobName,
  concurrency: QUEUE_POLICIES.providerCallback.concurrency,
  dlq: callbackDlq,
  processor: async (job) => {
    const data = getJobData(job);
    await processProviderCallback(data.providerCallbackId as string);
  },
});

buildWorker({
  queueName: QUEUE_POLICIES.merchantWebhook.queueName,
  jobName: QUEUE_POLICIES.merchantWebhook.jobName,
  concurrency: QUEUE_POLICIES.merchantWebhook.concurrency,
  dlq: webhookDlq,
  processor: async (job) => {
    const data = getJobData(job);
    await deliverWebhook(data.webhookDeliveryId as string);
  },
});

buildWorker({
  queueName: QUEUE_POLICIES.webhookInbound.queueName,
  jobName: QUEUE_POLICIES.webhookInbound.jobName,
  concurrency: QUEUE_POLICIES.webhookInbound.concurrency,
  dlq: webhookInboundDlq,
  processor: async (job) => {
    await handleWebhookInboundJob(job, webhookInboundDlq);
  },
});

buildWorker({
  queueName: QUEUE_POLICIES.reconcile.queueName,
  jobName: QUEUE_POLICIES.reconcile.jobName,
  concurrency: QUEUE_POLICIES.reconcile.concurrency,
  dlq: reconcileDlq,
  processor: async (job) => {
    const data = getJobData(job);
    await reconcilePayment(data.paymentIntentId as string);
  },
});

buildWorker({
  queueName: QUEUE_POLICIES.reconcileScheduler.queueName,
  jobName: QUEUE_POLICIES.reconcileScheduler.jobName,
  concurrency: QUEUE_POLICIES.reconcileScheduler.concurrency,
  dlq: reconcileSchedulerDlq,
  processor: async () => {
    const result = await enqueueReconcileCandidates();

    logger.info(
      {
        event: "reconcile.scheduler.scan_completed",
        queue: QUEUE_POLICIES.reconcileScheduler.queueName,
        candidates: result.candidates,
        enqueued: result.enqueued,
      },
      "reconcile.scheduler.scan_completed",
    );
  },
});

async function ensureRepeatableJobs() {
  await reconcileSchedulerQueue.add(
    QUEUE_POLICIES.reconcileScheduler.jobName,
    {},
    {
      jobId: "payment-reconcile-scan",
      repeat: {
        every: 60_000,
      },
      removeOnComplete: 1000,
      removeOnFail: 1000,
    },
  );

  logger.info(
    {
      event: "scheduler.registered",
      queue: QUEUE_POLICIES.reconcileScheduler.queueName,
      jobName: QUEUE_POLICIES.reconcileScheduler.jobName,
      everyMs: 60_000,
    },
    "scheduler.registered",
  );
}

void ensureRepeatableJobs().catch((error) => {
  logger.error(
    {
      event: "scheduler.registration_failed",
      queue: QUEUE_POLICIES.reconcileScheduler.queueName,
      error: serializeError(error),
    },
    "scheduler.registration_failed",
  );
});

logger.info(
  {
    event: "workers.started",
    queues: {
      providerCallback: QUEUE_POLICIES.providerCallback.queueName,
      merchantWebhook: QUEUE_POLICIES.merchantWebhook.queueName,
      webhookInbound: QUEUE_POLICIES.webhookInbound.queueName,
      reconcile: QUEUE_POLICIES.reconcile.queueName,
      reconcileScheduler: QUEUE_POLICIES.reconcileScheduler.queueName,
    },
  },
  "Workers started",
);
